sudo apt-get update
sudo apt-get install certbot

mkdir chat-app-backend
cd chat-app-backend
npm init -y
npm install express ws
