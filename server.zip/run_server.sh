./new_https_certs.sh
mv server.cert chat-app-backend
mv server.key chat-app-backend
cd chat-app-backend & npm start